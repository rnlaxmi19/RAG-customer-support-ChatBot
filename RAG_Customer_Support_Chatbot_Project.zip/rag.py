import os
import re
import requests
import numpy as np
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


class RAGEngine:
    """
    Simple Retrieval-Augmented Generation engine.

    Pipeline:
    PDF -> text extraction -> chunks -> embeddings -> retrieval
         -> context -> Ollama LLM -> answer + source citations
    """

    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.chunks = []
        self.embeddings = None
        self.llm_url = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
        self.llm_model = os.getenv("OLLAMA_MODEL", "llama3.2:3b")

    def chunk_text(self, text, chunk_size=900, overlap=150):
        text = re.sub(r"\s+", " ", text).strip()
        chunks = []

        start = 0
        while start < len(text):
            end = min(start + chunk_size, len(text))
            chunk = text[start:end].strip()

            if chunk:
                chunks.append(chunk)

            if end == len(text):
                break
            start = end - overlap

        return chunks

    def index_pdf(self, path):
        reader = PdfReader(path)
        added = 0

        for page_number, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            for chunk in self.chunk_text(text):
                self.chunks.append({
                    "text": chunk,
                    "source": os.path.basename(path),
                    "page": page_number
                })
                added += 1

        if not self.chunks:
            raise ValueError("No readable text was found in the PDF.")

        texts = [item["text"] for item in self.chunks]
        self.embeddings = self.model.encode(
            texts,
            normalize_embeddings=True,
            show_progress_bar=False
        )

        return added

    def retrieve(self, question, top_k=4):
        if not self.chunks or self.embeddings is None:
            return []

        q_embedding = self.model.encode(
            [question],
            normalize_embeddings=True,
            show_progress_bar=False
        )

        scores = cosine_similarity(q_embedding, self.embeddings)[0]
        indices = np.argsort(scores)[::-1][:top_k]

        results = []
        for idx in indices:
            results.append({
                **self.chunks[idx],
                "score": float(scores[idx])
            })

        return results

    def generate(self, question, contexts):
        context_text = "\n\n".join(
            f"[Source: {c['source']}, page {c['page']}]\n{c['text']}"
            for c in contexts
        )

        prompt = f"""
You are a customer support assistant.

Answer the user's question ONLY using the provided company-document context.
If the answer is not present in the context, say:
"I don't know based on the provided documents."

Do not invent policies, prices, dates, or features.
Keep the answer clear and helpful.

DOCUMENT CONTEXT:
{context_text}

USER QUESTION:
{question}

ANSWER:
"""

        response = requests.post(
            self.llm_url,
            json={
                "model": self.llm_model,
                "prompt": prompt,
                "stream": False
            },
            timeout=120
        )
        response.raise_for_status()
        return response.json().get("response", "").strip()

    def answer(self, question):
        contexts = self.retrieve(question)

        if not contexts:
            return (
                "Please upload a company PDF first. I don't have any documents to search.",
                []
            )

        # If similarity is very low, avoid confidently answering.
        if contexts[0]["score"] < 0.25:
            return (
                "I don't know based on the provided documents.",
                []
            )

        answer = self.generate(question, contexts)

        sources = [
            {
                "file": c["source"],
                "page": c["page"],
                "score": round(c["score"], 3)
            }
            for c in contexts
        ]

        return answer, sources
